import React, { useState, useEffect } from 'react';
import { Heart, Sparkles, Send, Music, ArrowRight, Calendar, Star, Volume2, Gamepad2, Award } from 'lucide-react';
import FallingElements from './components/FallingElements';
import MusicPlayer from './components/MusicPlayer';

// Import images so Vite bundles them correctly
// @ts-ignore
import giftBoxImg from './assets/images/pink_gift_box_1783150256830.jpg';
// @ts-ignore
import romanticBg from './assets/images/romantic_background_1783150272673.jpg';

// Custom SVG Symmetrical Calligraphy Divider matching the image's layout
const ElegantDivider = () => (
  <div className="flex items-center justify-center w-full px-6 my-3 opacity-95">
    <svg width="220" height="24" viewBox="0 0 220 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-pink-400">
      {/* Left Flourish with loops */}
      <path d="M 15 12 C 30 7, 35 17, 45 12 L 95 12" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" />
      <path d="M 15 12 C 10 12, 7 9, 10 7 C 13 5, 17 9, 15 12" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none" />
      <circle cx="92" cy="12" r="1.5" fill="currentColor" />
      
      {/* Center Delicate Heart */}
      <path d="M 110 15 C 108 12.5, 105.5 12.5, 105.5 14.5 C 105.5 17, 110 19.5, 110 19.5 C 110 19.5, 114.5 17, 114.5 14.5 C 114.5 12.5, 112 12.5, 110 15 Z" fill="currentColor" />
      
      {/* Right Flourish with loops */}
      <path d="M 205 12 C 190 7, 185 17, 175 12 L 125 12" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" fill="none" />
      <path d="M 205 12 C 210 12, 213 9, 210 7 C 207 5, 203 9, 205 12" stroke="currentColor" strokeWidth="1" strokeLinecap="round" fill="none" />
      <circle cx="128" cy="12" r="1.5" fill="currentColor" />
    </svg>
  </div>
);

// Left Rose Cluster decoration for the button corners
const RoseClusterLeft = () => (
  <div className="absolute -left-3.5 -bottom-1.5 z-30 pointer-events-none flex items-center justify-center scale-95 md:scale-100">
    <svg width="42" height="42" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-md">
      {/* Leaves */}
      <path d="M12 28C8 28 6 24 8 20C11 20 12 24 12 28Z" fill="#10b981" />
      <path d="M22 34C18 34 16 30 18 26C21 26 22 30 22 34Z" fill="#059669" opacity="0.9" />
      
      {/* First Rose Blossom */}
      <circle cx="15" cy="28" r="9" fill="url(#btnRose1)" />
      <circle cx="15" cy="28" r="6" fill="url(#btnRose2)" />
      <circle cx="15" cy="28" r="3.5" fill="url(#btnRose3)" />
      <path d="M15 22C17 22 19 24 18 26.5C17 29 13 29 12 26.5" stroke="#be123c" strokeWidth="0.85" strokeLinecap="round" fill="none" />
      <path d="M10 28C10 25.5 13 23.5 15 24.5C17 25.5 18 28 16.5 29.5" stroke="#be123c" strokeWidth="0.85" strokeLinecap="round" fill="none" />

      {/* Secondary Rose Blossom */}
      <circle cx="24" cy="24" r="7" fill="url(#btnRose1)" />
      <circle cx="24" cy="24" r="4.5" fill="url(#btnRose2)" />
      <circle cx="24" cy="24" r="2.5" fill="url(#btnRose3)" />
      <path d="M24 19.5C25.5 19.5 27 21 26 23C25 25 22 25 21 23" stroke="#be123c" strokeWidth="0.7" strokeLinecap="round" fill="none" />

      <defs>
        <linearGradient id="btnRose1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#fbcfe8" />
          <stop offset="100%" stopColor="#f43f5e" />
        </linearGradient>
        <linearGradient id="btnRose2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#f472b6" />
          <stop offset="100%" stopColor="#e11d48" />
        </linearGradient>
        <linearGradient id="btnRose3" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#e11d48" />
          <stop offset="100%" stopColor="#be123c" />
        </linearGradient>
      </defs>
    </svg>
  </div>
);

// Right Rose Cluster decoration for the button corners
const RoseClusterRight = () => (
  <div className="absolute -right-3.5 -bottom-1.5 z-30 pointer-events-none flex items-center justify-center scale-95 md:scale-100">
    <svg width="42" height="42" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-md">
      {/* Leaves */}
      <path d="M28 28C32 28 34 24 32 20C29 20 28 24 28 28Z" fill="#10b981" />
      <path d="M18 34C22 34 24 30 22 26C19 26 18 30 18 34Z" fill="#059669" opacity="0.9" />
      
      {/* First Rose Blossom */}
      <circle cx="25" cy="28" r="9" fill="url(#btnRose1)" />
      <circle cx="25" cy="28" r="6" fill="url(#btnRose2)" />
      <circle cx="25" cy="28" r="3.5" fill="url(#btnRose3)" />
      <path d="M25 22C23 22 21 24 22 26.5C23 29 27 29 28 26.5" stroke="#be123c" strokeWidth="0.85" strokeLinecap="round" fill="none" />
      <path d="M30 28C30 25.5 27 23.5 25 24.5C23 25.5 22 28 23.5 29.5" stroke="#be123c" strokeWidth="0.85" strokeLinecap="round" fill="none" />

      {/* Secondary Rose Blossom */}
      <circle cx="16" cy="24" r="7" fill="url(#btnRose1)" />
      <circle cx="16" cy="24" r="4.5" fill="url(#btnRose2)" />
      <circle cx="16" cy="24" r="2.5" fill="url(#btnRose3)" />
      <path d="M16 19.5C14.5 19.5 13 21 14 23C15 25 18 25 19 23" stroke="#be123c" strokeWidth="0.7" strokeLinecap="round" fill="none" />
    </svg>
  </div>
);

export default function App() {
  // Application states
  const [surpriseOpened, setSurpriseOpened] = useState(false);
  const [isShaking, setIsShaking] = useState(false);
  const [activeTab, setActiveTab] = useState<'letter' | 'memories' | 'quiz'>('letter');
  const [loveLevel, setLoveLevel] = useState(80);
  const [noBtnPos, setNoBtnPos] = useState({ x: 0, y: 0 });
  const [noBtnAttempts, setNoBtnAttempts] = useState(0);
  const [quizSuccess, setQuizSuccess] = useState(false);
  const [customReply, setCustomReply] = useState('');
  const [replySent, setReplySent] = useState(false);

  // Background decoration images (imported at top)

  // Handle the surprise button click
  const handleOpenSurprise = () => {
    setIsShaking(true);
    setTimeout(() => {
      setIsShaking(false);
      setSurpriseOpened(true);
    }, 800);
  };

  // Playful "No" button movement
  const handleNoButtonHover = () => {
    const randomX = Math.random() * 240 - 120; // safe boundaries
    const randomY = Math.random() * 120 - 60;
    setNoBtnPos({ x: randomX, y: randomY });
    setNoBtnAttempts(prev => prev + 1);
  };

  return (
    <div
      className="relative min-h-screen w-full flex items-center justify-center p-4 overflow-x-hidden"
      style={{
        backgroundImage: `url(${romanticBg})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed'
      }}
    >
      {/* Dynamic Falling Rose Petals and Hearts */}
      <FallingElements />

      {/* Music Box Button */}
      <MusicPlayer />

      {/* Main Container */}
      <div className="w-full max-w-[440px] z-20 transition-all duration-700 transform hover:scale-[1.01]">
        
        {/* Main Card */}
        {!surpriseOpened ? (
          /* SECTION 1: Exact Replication of the User's Image Card */
          <div 
            className="relative mx-auto w-full rounded-[48px] p-6 md:p-8 flex flex-col items-center justify-between overflow-hidden min-h-[790px] backdrop-blur-xl"
            style={{
              background: 'linear-gradient(135deg, rgba(255, 255, 255, 0.45) 0%, rgba(255, 235, 238, 0.4) 100%)',
              boxShadow: '0 30px 80px rgba(244, 63, 94, 0.22), inset 0 4px 30px rgba(255, 255, 255, 0.55)',
              border: '2px solid rgba(255, 255, 255, 0.75)'
            }}
          >
            
            {/* Top Glossy Aura */}
            <div className="absolute top-0 left-0 right-0 h-44 bg-gradient-to-b from-white/35 to-transparent pointer-events-none" />

            {/* Gift Box Area - Perfectly matches the card structure */}
            <div className="w-full flex justify-center mt-3 relative">
              <div
                className={`relative w-full aspect-square max-w-[340px] rounded-[36px] overflow-hidden transition-all duration-500 ${
                  isShaking ? 'animate-box-shake' : 'hover:scale-[1.03] animate-float-slow'
                }`}
              >
                <img
                  src={giftBoxImg}
                  alt="Special Pink Gift Box"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            {/* Middle Greeting Typography Panel */}
            <div className="w-full text-center flex flex-col items-center my-4">
              
              {/* To Arwa Heading */}
              <span className="text-[#643f4b] text-xl font-bold tracking-widest block mb-1">
                إلي :
              </span>
              
              <h1 className="text-[#db2777] text-6xl md:text-7xl font-black mt-1 drop-shadow-[0_4px_8px_rgba(219,39,119,0.15)] font-sans tracking-wide">
                أروى
              </h1>

              {/* Symmetrical Elegant Calligraphy Divider */}
              <ElegantDivider />

              {/* Personal Sub-header message */}
              <p className="text-[#5c2d37] text-[19px] md:text-xl font-bold flex items-center justify-center gap-1.5 mt-1.5">
                <span>حسين جايب لمج مفاجأة خاصة</span>
                <span className="inline-block text-rose-500 animate-pulse text-xl">💕</span>
              </p>
            </div>

            {/* Shiny 3D Hot Pink Button with Rose Corner Decorations */}
            <div className="w-full px-2 mb-2 relative mt-auto">
              
              {/* Left Rose Corner Decoration */}
              <RoseClusterLeft />

              {/* Right Rose Corner Decoration */}
              <RoseClusterRight />

              {/* Action Button - 3D Gel Capsule Styling */}
              <button
                onClick={handleOpenSurprise}
                id="main-action-btn"
                className="w-full relative py-4.5 px-8 rounded-full text-white font-bold text-xl md:text-2xl tracking-wide transition-all duration-300 transform hover:scale-[1.03] active:scale-[0.97] flex items-center justify-center gap-2.5 cursor-pointer select-none overflow-hidden"
                style={{
                  background: 'linear-gradient(to bottom, #ec4899 0%, #db2777 50%, #be123c 100%)',
                  boxShadow: '0 10px 25px rgba(225, 29, 72, 0.45), inset 0 3px 6px rgba(255, 255, 255, 0.4), inset 0 -3px 6px rgba(0, 0, 0, 0.25)',
                  border: '2.5px solid rgba(255, 255, 255, 0.5)',
                }}
              >
                {/* 3D Gel Reflection overlay */}
                <div className="absolute top-0 left-0 right-0 h-[48%] bg-gradient-to-b from-white/35 to-transparent rounded-t-full pointer-events-none" />
                
                {/* Highlight line */}
                <div className="absolute top-1 left-4 right-4 h-[1px] bg-white/40 pointer-events-none rounded-full" />

                <span className="relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.3)]">شنو هي المفاجأة؟</span>
                <span className="relative z-10 text-2xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.2)]">💝</span>
              </button>

              {/* Lower Radiant Pink Flare Glow */}
              <div className="absolute left-1/2 -bottom-2 -translate-x-1/2 w-4/5 h-3 bg-rose-500/80 blur-md rounded-full pointer-events-none animate-soft-pulse" />
            </div>

          </div>
        ) : (
          /* SECTION 2: Dynamic Interactive Surprise View after Unveiling */
          <div className="relative w-full glass-card rounded-[40px] p-5 md:p-8 flex flex-col shadow-[0_20px_60px_rgba(244,63,94,0.3)] border-2 border-white/80 overflow-hidden animate-heart-pop min-h-[720px]">
            
            {/* Surprise Card Header */}
            <div className="flex flex-col items-center text-center pb-4 border-b border-rose-200/50 mb-4">
              <div className="flex gap-2 items-center">
                <Sparkles className="w-5 h-5 text-yellow-500 animate-spin" />
                <h2 className="text-2xl md:text-3xl font-extrabold text-rose-700">مفاجأة أروى 💖</h2>
                <Sparkles className="w-5 h-5 text-yellow-500 animate-spin" />
              </div>
              <p className="text-xs text-rose-500 mt-1">بكل حب وتقدير من حسين</p>
            </div>

            {/* Interactive Tabs Menu */}
            <div className="grid grid-cols-3 gap-1.5 mb-6 p-1 bg-white/40 rounded-2xl border border-white/60">
              <button
                onClick={() => setActiveTab('letter')}
                id="tab-letter-btn"
                className={`py-2.5 px-2 text-center rounded-xl font-bold text-sm transition-all cursor-pointer ${
                  activeTab === 'letter'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-md'
                    : 'text-rose-700 hover:bg-white/30'
                }`}
              >
                💌 رسالة خاصة
              </button>
              <button
                onClick={() => setActiveTab('memories')}
                id="tab-memories-btn"
                className={`py-2.5 px-2 text-center rounded-xl font-bold text-sm transition-all cursor-pointer ${
                  activeTab === 'memories'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-md'
                    : 'text-rose-700 hover:bg-white/30'
                }`}
              >
                ✨ ذكرياتنا
              </button>
              <button
                onClick={() => setActiveTab('quiz')}
                id="tab-quiz-btn"
                className={`py-2.5 px-2 text-center rounded-xl font-bold text-sm transition-all cursor-pointer ${
                  activeTab === 'quiz'
                    ? 'bg-gradient-to-r from-rose-500 to-pink-500 text-white shadow-md'
                    : 'text-rose-700 hover:bg-white/30'
                }`}
              >
                🎮 تحدي الحب
              </button>
            </div>

            {/* Tab Contents */}
            <div className="flex-1 flex flex-col justify-between">
              
              {/* TAB 1: Love Letter */}
              {activeTab === 'letter' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="bg-white/70 border border-white p-5 rounded-3xl shadow-inner relative leading-relaxed text-rose-900 text-right font-serif">
                    {/* Decorative Watermark */}
                    <Heart className="absolute bottom-4 left-4 w-16 h-16 text-rose-100/60 pointer-events-none transform -rotate-12" />
                    
                    <p className="font-bold text-xl text-rose-600 mb-3">حبيبتي الغالية أروى، 💖</p>
                    <p className="mb-3 text-base md:text-lg">
                      اليوم صممت لك هذه المفاجأة الخاصة لأعبر لكِ عن مكانتك الكبيرة في قلبي. كل وردة تتساقط وكل نبضة في قلبي تناديكِ باسمكِ.
                    </p>
                    <p className="mb-3 text-base md:text-lg">
                      أنتِ لستِ مجرد شخص عادي، أنتِ النور الذي يضيء حياتي والبهجة التي تملأ أيامي. شكراً لأنكِ معي دائماً بجمال روحكِ ورقتكِ اللامتناهية.
                    </p>
                    <p className="font-bold text-rose-700 text-left mt-4 text-lg">محبكِ للأبد: حسين ✍️</p>
                  </div>

                  {/* Interactive Reply Board */}
                  <div className="space-y-2 mt-4">
                    <label className="block text-xs font-bold text-rose-700 mr-2">أرسلي رداً لطيفاً لحسين 💬</label>
                    {replySent ? (
                      <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-center rounded-2xl text-sm font-semibold animate-pulse">
                        تم إرسال ردك الجميل بنجاح إلى حسين! 💖💌
                      </div>
                    ) : (
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={customReply}
                          onChange={(e) => setCustomReply(e.target.value)}
                          placeholder="اكتبي رسالة قصيرة لحسين..."
                          className="flex-1 py-2 px-4 rounded-full bg-white/80 border border-rose-300 text-rose-900 placeholder-rose-400 focus:outline-none focus:ring-2 focus:ring-rose-400 text-sm text-right"
                        />
                        <button
                          onClick={() => {
                            if (customReply.trim()) setReplySent(true);
                          }}
                          id="send-reply-btn"
                          className="p-3 rounded-full bg-rose-500 hover:bg-rose-600 text-white transition-all cursor-pointer shadow-md"
                        >
                          <Send className="w-4 h-4 transform rotate-180" />
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: Custom Memories Carousel */}
              {activeTab === 'memories' && (
                <div className="space-y-4 animate-fade-in text-right">
                  <div className="grid grid-cols-1 gap-3">
                    
                    {/* Card 1 */}
                    <div className="bg-gradient-to-r from-rose-500/10 to-pink-500/10 p-4 rounded-2xl border border-rose-200 flex items-start gap-3">
                      <div className="p-2 bg-rose-500 text-white rounded-xl">
                        <Calendar className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-rose-800 text-sm md:text-base">كل الأوقات السعيدة</h4>
                        <p className="text-xs md:text-sm text-rose-950 mt-1">كل لحظة أقضيها معكِ هي بمثابة عيد، محفورة في ذاكرتي بأجمل الألوان.</p>
                      </div>
                    </div>

                    {/* Card 2 */}
                    <div className="bg-gradient-to-r from-rose-500/10 to-pink-500/10 p-4 rounded-2xl border border-rose-200 flex items-start gap-3">
                      <div className="p-2 bg-pink-500 text-white rounded-xl">
                        <Star className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-rose-800 text-sm md:text-base">نجمتي المضيئة</h4>
                        <p className="text-xs md:text-sm text-rose-950 mt-1">تضيئين عتمتي وتجعلينني أرى العالم بشكل أجمل وأروع.</p>
                      </div>
                    </div>

                    {/* Card 3 */}
                    <div className="bg-gradient-to-r from-rose-500/10 to-pink-500/10 p-4 rounded-2xl border border-rose-200 flex items-start gap-3">
                      <div className="p-2 bg-rose-600 text-white rounded-xl">
                        <Heart className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-rose-800 text-sm md:text-base">العهد الأبدي</h4>
                        <p className="text-xs md:text-sm text-rose-950 mt-1">أعدكِ بأن أظل السند والأمان، وأن أحميكِ بقلبي ما حييت.</p>
                      </div>
                    </div>

                  </div>

                  {/* Interactive Love Scale */}
                  <div className="bg-white/60 p-4 rounded-2xl border border-rose-100 space-y-2 mt-4 text-center">
                    <p className="text-xs font-bold text-rose-700">كم تحبين حسين؟ اختاري النسبة: 💓</p>
                    <input
                      type="range"
                      min="50"
                      max="100"
                      value={loveLevel}
                      onChange={(e) => setLoveLevel(Number(e.target.value))}
                      className="w-full accent-rose-500 h-2 bg-rose-200 rounded-lg cursor-pointer"
                    />
                    <div className="text-rose-600 font-extrabold text-lg">
                      {loveLevel}% {loveLevel === 100 ? 'إلى نهاية الكون وأبعد! 🌌✨' : 'وأكثر بكثير! 💖'}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: Interactive Romantic Quiz */}
              {activeTab === 'quiz' && (
                <div className="space-y-4 animate-fade-in">
                  {!quizSuccess ? (
                    <div className="bg-white/80 p-5 rounded-3xl border border-rose-200 text-center space-y-4">
                      <div className="w-12 h-12 bg-rose-100 rounded-full flex items-center justify-center mx-auto text-rose-600">
                        <Gamepad2 className="w-6 h-6" />
                      </div>
                      <h3 className="text-lg font-bold text-rose-800">لعبة القبول الأبدي! 💕</h3>
                      <p className="text-sm text-rose-950">هل تقبلين أن تبقي ملكة متوجة على عرش قلبي إلى الأبد؟</p>

                      <div className="flex flex-col sm:flex-row gap-3 justify-center items-center pt-2 relative min-h-[120px]">
                        
                        {/* Yes Button */}
                        <button
                          onClick={() => setQuizSuccess(true)}
                          id="quiz-yes-btn"
                          className="px-8 py-3 bg-gradient-to-r from-emerald-500 to-green-600 text-white font-bold rounded-full shadow-lg hover:scale-110 active:scale-95 transition-all cursor-pointer text-base"
                        >
                          نعم، بكل تأكيد! 💍💖
                        </button>

                        {/* No Button (Moves away) */}
                        <button
                          onMouseEnter={handleNoButtonHover}
                          onClick={handleNoButtonHover}
                          style={{
                            transform: `translate(${noBtnPos.x}px, ${noBtnPos.y}px)`,
                            transition: 'all 0.15s ease-out'
                          }}
                          id="quiz-no-btn"
                          className="px-6 py-2.5 bg-rose-200 text-rose-700 font-bold rounded-full text-xs shadow hover:bg-rose-300 border border-rose-300"
                        >
                          {noBtnAttempts === 0
                            ? 'لا 😢'
                            : noBtnAttempts < 3
                            ? 'أتحداك تضغطني! 😜'
                            : noBtnAttempts < 6
                            ? 'حاول مجدداً! 😂'
                            : 'مستحيل أسمحلك! 🔐'}
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-gradient-to-br from-yellow-50 to-amber-50 p-6 rounded-3xl border-2 border-amber-300 text-center space-y-4 animate-bounce-short">
                      <div className="w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mx-auto text-amber-500 shadow-md">
                        <Award className="w-10 h-10" />
                      </div>
                      <h3 className="text-xl font-black text-amber-800">لقد تم القبول الأبدي بنجاح! 🎉👑</h3>
                      <p className="text-sm text-amber-950 leading-relaxed">
                        أهلاً بكِ في عالم السعادة الأبدية! تم تسجيل الحب العظيم باسم "أروى وحسين" في نجوم الكون.
                      </p>
                      
                      <div className="p-3 bg-white/80 rounded-2xl border border-amber-200 font-mono text-xs text-amber-700">
                        كود وثيقة الحب: ARWA-HUSSEIN-FOREVER-999
                      </div>

                      <button
                        onClick={() => {
                          setQuizSuccess(false);
                          setNoBtnAttempts(0);
                          setNoBtnPos({ x: 0, y: 0 });
                        }}
                        id="play-again-btn"
                        className="text-xs text-rose-500 font-bold underline hover:text-rose-700 cursor-pointer"
                      >
                        إعادة التحدي الطريف 🔄
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Back to Original View Button */}
              <button
                onClick={() => setSurpriseOpened(false)}
                id="back-to-gift-btn"
                className="mt-6 flex items-center justify-center gap-1.5 text-xs text-rose-600 hover:text-rose-800 transition-all font-bold cursor-pointer self-center py-2 px-4 rounded-full bg-rose-50/50 hover:bg-rose-100"
              >
                <ArrowRight className="w-3.5 h-3.5" />
                <span>العودة لبطاقة الهدية</span>
              </button>

            </div>

          </div>
        )}

        {/* Footer Credit Tag (Very minimal and polished, matching designer standards) */}
        <div className="text-center mt-6 text-rose-700/80 text-xs font-semibold tracking-wide flex items-center justify-center gap-1.5 drop-shadow-sm">
          <span>صُمم بكل الحب لأجمل أروى</span>
          <Heart className="w-3 h-3 text-rose-500 fill-rose-500 animate-pulse" />
        </div>

      </div>
    </div>
  );
}
