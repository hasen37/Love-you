import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

export default function MusicPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const nextNoteTimeRef = useRef<number>(0);
  const timeoutIdRef = useRef<number | null>(null);
  const notesIndexRef = useRef<number>(0);

  // Sweet music box chord progression (frequencies in Hz)
  // C major, F major, G major, Am, F major, G major, C major
  const melody = [
    261.63, 329.63, 392.00, 523.25, // C4, E4, G4, C5
    349.23, 440.00, 523.25, 698.46, // F4, A4, C5, F5
    392.00, 493.88, 587.33, 783.99, // G4, B4, D5, G5
    440.00, 523.25, 659.25, 880.00, // A4, C5, E5, A5
    349.23, 440.00, 523.25, 698.46, // F4, A4, C5, F5
    392.00, 493.88, 587.33, 783.99, // G4, B4, D5, G5
    523.25, 659.25, 783.99, 1046.50 // C5, E5, G5, C6
  ];

  const playNote = (freq: number, time: number) => {
    if (!audioContextRef.current) return;
    const ctx = audioContextRef.current;

    // Create oscillator and gain node
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    // Use a soft sine/triangle wave for a music box sound
    osc.type = 'triangle';
    osc.frequency.value = freq;

    // Music box envelope (rapid attack, long slow decay)
    gain.gain.setValueAtTime(0, time);
    gain.gain.linearRampToValueAtTime(0.15, time + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(time);
    osc.stop(time + 1.3);
  };

  const scheduler = () => {
    if (!audioContextRef.current || !isPlaying) return;
    const ctx = audioContextRef.current;

    while (nextNoteTimeRef.current < ctx.currentTime + 0.1) {
      const currentFreq = melody[notesIndexRef.current % melody.length];
      playNote(currentFreq, nextNoteTimeRef.current);

      // Schedule next note (soft arpeggio speed: 300ms)
      nextNoteTimeRef.current += 0.35;
      notesIndexRef.current += 1;
    }

    timeoutIdRef.current = window.setTimeout(scheduler, 25);
  };

  const toggleMusic = () => {
    if (!isPlaying) {
      // Start audio context
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      if (audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume();
      }
      nextNoteTimeRef.current = audioContextRef.current.currentTime + 0.05;
      setIsPlaying(true);
    } else {
      setIsPlaying(false);
      if (timeoutIdRef.current) {
        clearTimeout(timeoutIdRef.current);
      }
    }
  };

  useEffect(() => {
    if (isPlaying) {
      scheduler();
    } else {
      if (timeoutIdRef.current) {
        clearTimeout(timeoutIdRef.current);
      }
    }
    return () => {
      if (timeoutIdRef.current) {
        clearTimeout(timeoutIdRef.current);
      }
    };
  }, [isPlaying]);

  return (
    <div className="fixed top-4 left-4 z-50">
      <button
        onClick={toggleMusic}
        id="toggle-music-btn"
        className="flex items-center gap-2 px-3 py-2 rounded-full bg-white/40 backdrop-blur-md border border-white/50 text-rose-600 hover:bg-white/60 transition-all duration-300 shadow-md hover:scale-105 active:scale-95"
      >
        {isPlaying ? (
          <>
            <Volume2 className="w-4 h-4 animate-bounce" />
            <div className="flex gap-0.5 items-end h-3">
              <span className="w-0.5 bg-rose-500 animate-[bounce_0.8s_infinite_0.1s] h-full" />
              <span className="w-0.5 bg-rose-500 animate-[bounce_0.6s_infinite_0.3s] h-3/4" />
              <span className="w-0.5 bg-rose-500 animate-[bounce_0.9s_infinite_0.2s] h-1/2" />
            </div>
            <span className="text-xs font-semibold ml-1">موسيقانا 💖</span>
          </>
        ) : (
          <>
            <VolumeX className="w-4 h-4" />
            <span className="text-xs font-semibold ml-1">تشغيل الموسيقى 🎵</span>
          </>
        )}
      </button>
    </div>
  );
}
