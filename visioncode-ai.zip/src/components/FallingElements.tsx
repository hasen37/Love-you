import React, { useEffect, useState } from 'react';

interface FallingItem {
  id: number;
  left: number; // percentage (0-100)
  delay: number; // seconds (0-10)
  duration: number; // seconds (8-20)
  size: number; // pixels (12-32)
  rotation: number; // degrees (0-360)
  type: 'petal' | 'heart';
}

export default function FallingElements() {
  const [items, setItems] = useState<FallingItem[]>([]);

  useEffect(() => {
    // Generate static random values once on mount to avoid hydration mismatch and infinite loops
    const generatedItems: FallingItem[] = Array.from({ length: 30 }).map((_, i) => {
      const type = Math.random() > 0.4 ? 'petal' : 'heart';
      return {
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 12,
        duration: 8 + Math.random() * 12, // 8s to 20s
        size: 12 + Math.random() * 20, // 12px to 32px
        rotation: Math.random() * 360,
        type,
      };
    });
    setItems(generatedItems);
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
      {items.map((item) => (
        <div
          key={item.id}
          className="absolute opacity-0"
          style={{
            left: `${item.left}%`,
            top: '-5%',
            animationName: 'petalFall',
            animationDuration: `${item.duration}s`,
            animationDelay: `${item.delay}s`,
            animationIterationCount: 'infinite',
            animationTimingFunction: 'linear',
            transform: `rotate(${item.rotation}deg)`,
          }}
        >
          {item.type === 'petal' ? (
            /* Elegant curved rose petal SVG */
            <svg
              width={item.size}
              height={item.size}
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-pink-400 drop-shadow-[0_2px_4px_rgba(244,63,94,0.15)]"
            >
              <path
                d="M12 2C17.5 2 21 6.5 21 11C21 15.5 17 21 12 21C7 21 3 16.5 3 12C3 7.5 6.5 2 12 2Z"
                fill="url(#petalGradient)"
              />
              <path
                d="M12 2C14.5 5.5 15.5 9.5 12 13"
                stroke="#fda4af"
                strokeWidth="1"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="petalGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fbcfe8" />
                  <stop offset="50%" stopColor="#f43f5e" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#e11d48" stopOpacity="0.95" />
                </linearGradient>
              </defs>
            </svg>
          ) : (
            /* Beautiful heart SVG */
            <svg
              width={item.size * 0.85}
              height={item.size * 0.85}
              viewBox="0 0 24 24"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="text-rose-500 drop-shadow-[0_2px_5px_rgba(225,29,72,0.2)]"
            >
              <path
                d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
                fill="url(#heartGradient)"
              />
              <defs>
                <linearGradient id="heartGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fda4af" />
                  <stop offset="50%" stopColor="#f43f5e" />
                  <stop offset="100%" stopColor="#be123c" />
                </linearGradient>
              </defs>
            </svg>
          )}
        </div>
      ))}
    </div>
  );
}
